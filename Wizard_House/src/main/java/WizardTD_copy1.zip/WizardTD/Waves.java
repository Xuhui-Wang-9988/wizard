package WizardTD;

import processing.core.PApplet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Waves {
    PApplet pApplet;
    int preWavePause; // in seconds
    int duration; // in seconds
    List<WaveInfo> monstersInfo;
    Board board;

    List<Monsters> activeMonsters = new ArrayList<>();
    int currentMonsterIndex = 0;
    int frameCounter = 0;
    int waveNumber;
    boolean isWaveActive = false;
    boolean isWaveComplete = false;

    public Waves(PApplet pApplet, int preWavePause, int duration, List<WaveInfo> monstersInfo, int waveNumber, Board board) {
        this.pApplet = pApplet;
        this.preWavePause = preWavePause;
        this.duration = duration;
        this.monstersInfo = monstersInfo;
        this.waveNumber = waveNumber;
        this.board = board;
    }

    public void update() {
        if (!isWaveActive) {
            preWavePause();
        } else {
            spawnMonsters();
        }
        frameCounter++;
    }

    private void preWavePause() {
        if (frameCounter >= preWavePause * 60) { // convert seconds to frames
            frameCounter = 0;
            isWaveActive = true;
        }
        pApplet.text("Wave " + waveNumber + " starts: " + (preWavePause - frameCounter / 60), 10, 10);
    }


private void spawnMonsters() {
    if (frameCounter % (duration * 60 / getTotalMonsters()) == 0 && currentMonsterIndex < getTotalMonsters()) {
//        List<int[]> startPoints = findStartPoints(board);
//        int[] startPoint = startPoints.get(pApplet.floor(pApplet.random(startPoints.size())));
        int[] startPoint = {0,4};
        Monsters newMonster = new Monsters(pApplet, "gremlin", startPoint[0], startPoint[1], /*speed=*/1, /*health=*/100, /*armour=*/0.1f, /*manaGainedOnKill=*/5);
        activeMonsters.add(newMonster);
        currentMonsterIndex++;
    }
    if (currentMonsterIndex >= getTotalMonsters()) {
        isWaveComplete = true;
    }
}


    public void updateMonsters() {
        // 使用迭代器来安全地在迭代过程中删除元素
        Iterator<Monsters> iterator = activeMonsters.iterator();
        while (iterator.hasNext()) {
            Monsters monster = iterator.next();
            monster.move(); // 确保移动怪物
            monster.display(); // 确保显示怪物

            if (monster.isDead()) {
                // 如果怪物死了，可能你想给玩家一些奖励或分数
                // yourCodeHere();
                iterator.remove();
            } else if (monster.hasReachedEnd(board)) { // 确保传递board对象
                // 如果怪物到达终点，你可能想减少玩家的生命值或进行其他操作
                // yourCodeHere();
                iterator.remove();
            }
        }
    }


    private int getTotalMonsters() {
        return monstersInfo.stream().mapToInt(WaveInfo::getQuantity).sum();
    }

    public boolean isWaveComplete() {
        return isWaveComplete;
    }


}


