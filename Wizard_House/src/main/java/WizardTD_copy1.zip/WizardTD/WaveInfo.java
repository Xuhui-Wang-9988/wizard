package WizardTD;

public class WaveInfo {
    int quantity; // number of monsters


    public WaveInfo(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }
}

