package WizardTD;

import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;
import processing.event.MouseEvent;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import java.util.*;

public class App extends PApplet {

    public static final int CELLSIZE = 32;
    public static final int SIDEBAR = 120;
    public static final int TOPBAR = 40;
    public static final int BOARD_WIDTH = 20;

    public static int WIDTH = CELLSIZE*BOARD_WIDTH+SIDEBAR;
    public static int HEIGHT = BOARD_WIDTH*CELLSIZE+TOPBAR;

    public static final int FPS = 60;

    public String configPath;

    public Random random = new Random();
	
	// Feel free to add any additional methods or attributes you want. Please put classes in different files.
    Waves currentWave;
    List<WaveInfo> waveInfoList = new ArrayList<>();
    JSONArray waves;
    int currentWaveIndex = 0;
    int currentMonsterIndex = 0;
    int monsterSpawnTimer = 0;

    public App() {
        this.configPath = "config.json";
    }

    /**
     * Initialise the setting of the window size.
     */
	@Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
     * Load all resources such as images. Initialise the elements such as the player, enemies and map elements.
     */

    //default map level: level1, the first map

    private String layout;
    private float initial_tower_range;
    private float initial_tower_firing_speed;
    private float initial_tower_damage;
    private float initial_mana;
    private float initial_mana_cap;
    private float initial_mana_gained_per_second;
    private float tower_cost;
    private float mana_pool_spell_initial_cost;
    private float mana_pool_spell_cost_increase_per_use;
    private float mana_pool_spell_cap_multiplier;
    private float mana_pool_spell_mana_gained_multiplier;
    private float duration;
    private float preWavePause;
    private String type;
    private float HP;
    private float speed;
    private float armour;
    private float mana_gained_on_kill;
    private int quantity;

    Board maploader;
    Wizard wizard;

    ArrayList<Monsters> enemies = new ArrayList<>();

    private void loadConfig() {
        // Load and parse the JSON data
        JSONObject config = loadJSONObject("config.json");

        // Accessing basic attributes
        layout = config.getString("layout");
        initial_tower_range = config.getFloat("initial_tower_range");
        initial_tower_firing_speed = config.getFloat("initial_tower_firing_speed");
        initial_tower_damage = config.getFloat("initial_tower_damage");
        initial_mana = config.getFloat("initial_mana");
        initial_mana_cap = config.getFloat("initial_mana_cap");
        initial_mana_gained_per_second = config.getFloat("initial_mana_gained_per_second");
        tower_cost = config.getFloat("tower_cost");
        mana_pool_spell_initial_cost = config.getFloat("mana_pool_spell_initial_cost");
        mana_pool_spell_cost_increase_per_use = config.getFloat("mana_pool_spell_cost_increase_per_use");
        mana_pool_spell_cap_multiplier = config.getFloat("mana_pool_spell_cap_multiplier");
        mana_pool_spell_mana_gained_multiplier = config.getFloat("mana_pool_spell_mana_gained_multiplier");

        // Accessing array of waves
        waves = config.getJSONArray("waves");  // 注意这里没有“JSONArray”类型的声明
        for (int i = 0; i < waves.size(); i++) {
            JSONObject wave = waves.getJSONObject(i);
            duration = wave.getFloat("duration");
            preWavePause = wave.getFloat("pre_wave_pause");

            // Accessing monsters within a wave
            JSONArray monsters = wave.getJSONArray("monsters");
            for (int j = 0; j < monsters.size(); j++) {
                JSONObject monster = monsters.getJSONObject(j);
                type = monster.getString("type");
                HP = monster.getFloat("hp");
                speed = monster.getFloat("speed");
                armour = monster.getFloat("armour");
                mana_gained_on_kill = monster.getFloat("mana_gained_on_kill");
                quantity = monster.getInt("quantity");
            }
        }
    }

    @Override
    public void setup() {
        frameRate(FPS);
        // Map loader
        loadConfig();

        maploader = new Board(this, layout );
        wizard = new Wizard(this, maploader);

        // Enemy Loader
        String[] enemyImages = {
                "src/main/resources/WizardTD/grembin.png",
                "src/main/resources/WizardTD/grembin1.png",
                "src/main/resources/WizardTD/grembin2.png",
                "src/main/resources/WizardTD/grembin3.png",
                "src/main/resources/WizardTD/grembin4.png",
                "src/main/resources/WizardTD/grembin5.png"};

        // add waves
        waveInfoList.add(new WaveInfo(/*quantity=*/5));
        waveInfoList.add(new WaveInfo(/*quantity=*/3));

        currentWave = new Waves(this, /*preWavePause=*/5, /*duration=*/10, waveInfoList, /*waveNumber=*/1, maploader);


    }

    /**
     * Receive key pressed signal from the keyboard.
     */
	@Override
    public void keyPressed(){
        
    }

    /**
     * Receive key released signal from the keyboard.
     */
	@Override
    public void keyReleased(){

    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    /*@Override
    public void mouseDragged(MouseEvent e) {

    }*/

    /**
     * Draw all elements in the game by current frame.
     */
	@Override
    public void draw() {
        background(131,112,75);
//            rect(0, 0, width, );
        maploader.draw();
        wizard.draw();

        // Update and draw monsters
        currentWave.update();
        currentWave.updateMonsters();

        // Check if the wave is complete and prepare the next wave if needed
        if (currentWave.isWaveComplete()) {
            // Logic to initialize the next wave
            // Example: currentWave = new Waves(this, 5, 10, nextWaveInfoList, 2, maploader);
        }
 
    }

    public static void main(String[] args) {
        PApplet.main("WizardTD.App");
    }

    /**
     * Source: https://stackoverflow.com/questions/37758061/rotate-a-buffered-image-in-java
     * @param pimg The image to be rotated
     * @param angle between 0 and 360 degrees
     * @return the new rotated image
     */
    public PImage rotateImageByDegrees(PImage pimg, double angle) {
        BufferedImage img = (BufferedImage) pimg.getNative();
        double rads = Math.toRadians(angle);
        double sin = Math.abs(Math.sin(rads)), cos = Math.abs(Math.cos(rads));
        int w = img.getWidth();
        int h = img.getHeight();
        int newWidth = (int) Math.floor(w * cos + h * sin);
        int newHeight = (int) Math.floor(h * cos + w * sin);

        PImage result = this.createImage(newWidth, newHeight, RGB);
        //BufferedImage rotated = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        BufferedImage rotated = (BufferedImage) result.getNative();
        Graphics2D g2d = rotated.createGraphics();
        AffineTransform at = new AffineTransform();
        at.translate((newWidth - w) / 2, (newHeight - h) / 2);

        int x = w / 2;
        int y = h / 2;

        at.rotate(rads, x, y);
        g2d.setTransform(at);
        g2d.drawImage(img, 0, 0, null);
        g2d.dispose();
        for (int i = 0; i < newWidth; i++) {
            for (int j = 0; j < newHeight; j++) {
                result.set(i, j, rotated.getRGB(i, j));
            }
        }

        return result;
    }
}
