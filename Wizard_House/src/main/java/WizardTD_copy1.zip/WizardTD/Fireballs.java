package WizardTD;

public class Fireballs {
}
