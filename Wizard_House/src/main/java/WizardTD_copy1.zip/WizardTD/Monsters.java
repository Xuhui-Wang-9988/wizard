package WizardTD;

import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;

public class Monsters {
    String type;
    int x, y; // Position
    float speed;
    int maxHP;
    int currentHP;
    float armour;
    int manaGainedOnKill;
    PImage[] enemyImages;
    int currentImageIndex = 0;
    int deathAnimationCounter = 0;

    private int pathIndex = 0; // 用于跟踪怪物当前在路径上的位置

    private int[][] path = {
        {0,4},
        {4,4},
        {4,6},
        {16,6},
        {16,9},
        {10,9},
        {10,15},
        {3,15}

    }; // 存储怪物的移动路径


    private float accumulatedMoveX = 0.0f; // 累积的X方向移动量
    private float accumulatedMoveY = 0.0f; // 累积的Y方向移动量

    int prevX, prevY; // Previous position
    PApplet pApplet;

    public Monsters(PApplet pApplet, String type, int startX, int startY,
                    float speed, int HP, float armour, int manaGainedOnKill) {
        this.pApplet = pApplet;
        this.type = type;
        this.x = startX;
        this.y = startY;
        this.speed = speed / 20;
        this.maxHP = HP;
        this.currentHP = HP;
        this.armour = armour;
        this.manaGainedOnKill = manaGainedOnKill;
        String[] imagePaths = {
                "src/main/resources/WizardTD/gremlin.png",
                "src/main/resources/WizardTD/gremlin1.png",
                "src/main/resources/WizardTD/gremlin2.png",
                "src/main/resources/WizardTD/gremlin3.png",
                "src/main/resources/WizardTD/gremlin4.png",
                "src/main/resources/WizardTD/gremlin5.png"};
        this.enemyImages = new PImage[imagePaths.length];

        for (int i = 0; i < imagePaths.length; i++) {
            this.enemyImages[i] = pApplet.loadImage(imagePaths[i]);
        }
    }




    public void move() {
        if (pathIndex < path.length - 1) {
            int targetX = path[pathIndex + 1][0] ; // 目标点的像素X坐标
            int targetY = path[pathIndex + 1][1]; // 目标点的像素Y坐标

            float dx = targetX - x; // X方向的距离
            float dy = targetY - y; // Y方向的距离

            // 计算单位向量
            float length = (float) Math.sqrt(dx * dx + dy * dy);
            float ux = dx / length;
            float uy = dy / length;

            // 更新累积的移动量
            accumulatedMoveX += ux * speed;
            accumulatedMoveY += uy * speed;

            // 更新怪物的位置
            x += (int) accumulatedMoveX;
            y += (int) accumulatedMoveY;

            // 更新累积的移动量的余数
            accumulatedMoveX %= 1.0f;
            accumulatedMoveY %= 1.0f;

            // 检查是否到达目标点
            if (Math.abs(x - targetX) < speed && Math.abs(y - targetY) < speed) {
                pathIndex++; // 移动到路径的下一个点
            }
        } else {
            // 如果怪物已经到达路径的终点，你可以在这里添加其他的逻辑
            // 例如，减少玩家的生命值或者移除这个怪物对象
        }
    }

    public void display() {
        if (isDead()) {
            if (currentImageIndex < enemyImages.length - 1 && deathAnimationCounter % 4 == 0) {
                currentImageIndex++;
            }
            deathAnimationCounter++;
        }

        // Convert grid coordinates to pixel coordinates for drawing
        int drawX = x * App.CELLSIZE;
        int drawY = y * App.CELLSIZE;

        pApplet.image(enemyImages[currentImageIndex], drawX, drawY);
        displaycurrentHPBar();
    }

    private int convertToPixelCoordinate(int gridCoordinate) {
        return gridCoordinate * App.CELLSIZE;
    }


    public void takeDamage(int damage) {
        currentHP -= damage * (1 - armour); // Reduce currentHP by the damage amount, considering armour
    }

    public boolean isDead() {
        return currentHP <= 0;
    }

    private void displaycurrentHPBar() {
        float currentHPPercentage = (float) currentHP / maxHP;
        pApplet.fill(255, 0, 0); // Red color for the background of the currentHP bar
        pApplet.rect(x * App.CELLSIZE, y * App.CELLSIZE - 10, enemyImages[0].width, 5); // Draw background
        pApplet.fill(0, 255, 0); // Green color for the actual currentHP bar
        pApplet.rect(x * App.CELLSIZE, y * App.CELLSIZE - 10, enemyImages[0].width * currentHPPercentage, 5); // Draw currentHP
    }


    public boolean hasReachedEnd(Board board) {
        int[] wizardHousePosition = board.findWizardHousePosition();

        // Check if the monster's position is the same as the wizard house's position
        return x == wizardHousePosition[1] && y == wizardHousePosition[0];
    }



}
